 		<meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>In store Look</title>
        
        <!-- Bootstrap -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/themes/bootstrap/css/bootstrap.min.css">
        <!-- Custom -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/themes/custom/css/animate.css">
        <!-- Custom -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/themes/custom/css/owl.carousel.css">
        <!-- Jasny -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/themes/jasny/css/jasny-bootstrap.css">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.min.css">
        <!-- Typeahead -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/themes/typeahead/css/typeahead.css">
        <!-- Custom -->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/themes/custom/css/table.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/themes/custom/css/style.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/themes/view_mode_switch/';?>css/default.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/themes/view_mode_switch/';?>css/component.css" />
        
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <!-- Jquery  --> 
        <script type="text/javascript" src="<?php echo base_url();?>assets/themes/custom/js/jquery-2.1.1.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/themes/custom/js/table.js"></script>
        <script src="<?php echo base_url().'assets/themes/view_mode_switch/';?>js/modernizr.custom.js"></script>