<div id="the-basics">
                                    	<input class="typeahead" type="text" placeholder="States of USA">
                                    </div>