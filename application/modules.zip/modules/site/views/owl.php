
    
    <div class="owl-carousel" id="owl-recent">
        <div class="item"> <img src="http://placehold.it/200x300&text=ISL"> </div>
        <div class="item"> <img src="http://placehold.it/200x300&text=ISL"> </div>
        <div class="item"> <img src="http://placehold.it/200x300&text=ISL"> </div>
        <div class="item"> <img src="http://placehold.it/200x300&text=ISL"> </div>
        <div class="item"> <img src="http://placehold.it/200x300&text=ISL"> </div>
        <div class="item"> <img src="http://placehold.it/200x300&text=ISL"> </div>
        <div class="item"> <img src="http://placehold.it/200x300&text=ISL"> </div>
    </div>
    