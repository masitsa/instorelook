<div class="container main-container headerOffset">
    <div class="row">
    
        <!--right column-->
        <div class="col-lg-12 col-md-12 col-sm-12 product-content">
        
            <div class="center-align">
                <h4>We are unable to find what you are looking for :-(</h4>
                
                <p>
                    We were not able to find what you are looking for maybe you could:
                </p>
                
                <a href="<?php echo site_url().$came;?>" class="btn btn-primary">go back from whence you came</a>
                <a href="<?php echo site_url().'products';?>" class="btn btn-success">buy something nice</a>
            </div>
        </div><!--/right column end-->
    </div><!-- /.row  --> 
</div><!-- /main container -->