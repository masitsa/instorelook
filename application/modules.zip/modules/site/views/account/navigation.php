<div class="col-lg-12 clearfix">
    <ul class="pager">
        <li class="previous pull-right"><a href="<?php echo site_url().'products';?>"> <i class="fa fa-home"></i> Go to Shop </a></li>
        <li class="next pull-left"><a href="<?php echo site_url().'customer/account';?>"> &larr; Back to My Account</a></li>
    </ul>
</div>