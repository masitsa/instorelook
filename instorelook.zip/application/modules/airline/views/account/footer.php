

    <!-- jQuery Version 1.11.0 -->
    <script src="<?php echo base_url();?>assets/themes/sb-admin/js/jquery-1.11.0.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/themes/sb-admin/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url();?>assets/themes/sb-admin/js/plugins/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="<?php echo base_url();?>assets/themes/sb-admin/js/plugins/morris/raphael.min.js"></script>
    <script src="<?php echo base_url();?>assets/themes/sb-admin/js/plugins/morris/morris.min.js"></script>
    <script src="<?php echo base_url();?>assets/themes/sb-admin/js/plugins/morris/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url();?>assets/themes/sb-admin/js/sb-admin-2.js"></script>