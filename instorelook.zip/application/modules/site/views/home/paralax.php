


<div class="parallax-section parallax-image-1">
  <div class="container">
    <div class="row ">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <div class="parallax-content clearfix">
          <h1 class="parallaxPrce"> KES 0 </h1>
          <h2 class="uppercase">FREE Delivery within the CBD</h2><br/>
          <h3 > For any purchase that you make we provide free delivery within the CBD </h3>
          <div style="clear:both"></div>
          <a class="btn btn-discover " href="<?php echo site_url()."products/all-products";?>"> <i class="fa fa-shopping-cart"></i> SHOP NOW </a> </div>
      </div>
    </div>
    <!--/.row--> 
  </div>
  <!--/.container--> 
</div>
<!--/.parallax-image-1-->