

<div class="parallax-section parallax-image-2">
  <div class="w100 parallax-section-overley">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <div class="parallax-content clearfix">
            <h1 class="xlarge"> HIGHEST QUALITY PRODUCTS </h1>
            <h5 class="parallaxSubtitle"> At the most affordable prices </h5>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--/.parallax-section-->